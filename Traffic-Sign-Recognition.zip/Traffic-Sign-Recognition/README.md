# Traffic Sign Recognition

Recognize traffic signs from images using computer vision and deep learning.

## Technologies
- Python
- TensorFlow
- OpenCV
- Flask

## Run
pip install -r requirements.txt
python app.py

from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "<h1>Traffic Sign Recognition</h1><p>Starter project is ready.</p>"

if __name__ == "__main__":
    app.run(debug=True)
